from .models import Profile, Recipes

def base_context(request):
    context = {}
    
    if request.user.is_authenticated:
            context['profile'] = Profile.objects.get(user=request.user)

    if request.user.is_authenticated:
            context['recipes'] = Recipes.objects.get_userid(request.user)

    return context