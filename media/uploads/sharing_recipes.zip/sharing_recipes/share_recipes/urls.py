from django.urls import path
from .views import HomeView, Register_view, Signin_view, ProfileView, ShareRecipesView, RecipesView, CommentCreateView
from django.views.generic import RedirectView

urlpatterns = [
    path('home/', HomeView.as_view(), name='home'),
    path('login/', Signin_view.as_view(), name='login'),
    path('profile/<int:pk>/', ProfileView.as_view(), name='profile'),
    path('recipe/<int:pk>/', RecipesView.as_view(), name='recipe'),
    path('sharing/', ShareRecipesView.as_view(), name='share'),
    path('register/', Register_view.as_view(), name='register'),
    path('comments/<int:recipe_id>/', CommentCreateView.as_view(), name='add_comment'),
    path('', RedirectView.as_view(pattern_name='home')),
]
