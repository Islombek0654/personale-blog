from django.contrib import admin
from .models import Profile, Recipes, Comment

admin.site.register(Profile)
admin.site.register(Recipes)
admin.site.register(Comment)