from django.shortcuts import render
from django.views.generic import ListView, View, CreateView, DeleteView, FormView, DetailView
from .forms import RegisterForm, LoginForm, ShareRecipeForm
from .models import Profile, Recipes, Comment
from django.shortcuts import get_object_or_404
from django.urls import reverse_lazy
from django.http import HttpResponseRedirect
from django.contrib.auth.views import LogoutView


class HomeView(ListView):
    model = Profile
    template_name = 'index.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        recipes = Recipes.objects.select_related('user','user__user')
        context['recipes'] = recipes
        return context



class Register_view(CreateView):
    template_name = 'register.html'
    form_class = RegisterForm
    success_url = 'login'


class Signin_view(FormView):
    template_name = 'login.html'
    form_class = LoginForm
    success_url = reverse_lazy('home')


class ProfileView(DetailView):
    model = Profile
    template_name = 'profile.html'
    context_object_name = 'profile'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profile = self.object
        user = profile.user
        recipes = Recipes.objects.get_userid(self.request.user) 
        context['recipes'] = recipes
        return context


class RecipesView(DetailView):
    model = Recipes
    template_name = 'recipe.html'
    context_object_name = 'recipe'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        recipe = self.object
        comments = Comment.objects.filter(recipe__id=recipe.id).select_related('user', 'recipe')
        context['comments'] = comments
        return context


class ShareRecipesView(CreateView):
    template_name = 'sharing.html'
    form_class = ShareRecipeForm    
    

    def get_success_url(self):
        return self.request.META.get('HTTP_REFERER')


    def form_valid(self, form):
        form.instance.user = self.request.user.profile
        return super().form_valid(form)





class CommentCreateView(CreateView):
    model = Comment
    fields = ['content']
    template_name = 'comment_form.html'

    def form_valid(self, form):
        recipe = get_object_or_404(Recipes, id=self.kwargs['recipe_id'])
        form.instance.user = self.request.user.profile
        form.instance.recipe = recipe
        return super().form_valid(form)

    def get_success_url(self):
        return self.request.META.get('HTTP_REFERER', '/')
    