from django.db.models import Manager


class UserManager(Manager):

    def get_userid(self, user):
        return self.get_queryset().filter(user__user=user).select_related('user')