from django.db import models
from django.contrib.auth.models import User
from django_ckeditor_5.fields import CKEditor5Field
from .manager import UserManager

class Profile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE, db_index=True )
    phone = models.CharField(max_length=150)
    bio = models.TextField()
    avatar = models.ImageField(upload_to='profile_images/')

    def __str__(self):
        return self.user.username


class Recipes(models.Model):
    user = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name='recipes_user')
    title = models.CharField(max_length=150,blank=True,null=True)
    content = CKEditor5Field()
    image = models.ImageField(upload_to='recipes_image/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    objects = UserManager()


class Comment(models.Model):
    user = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name='comment_user')
    content = models.CharField(max_length=250)
    recipe = models.ForeignKey(Recipes, on_delete=models.CASCADE, related_name='recipe',null=True)


     