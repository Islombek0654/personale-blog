from django.urls import path
from .views import hello, jahon, sport

urlpatterns = [
    path('', hello, name='home'),
    path('jahon/', jahon, name='jahon'),
    path('sport/', sport, name='sport'),
]