from django.shortcuts import render
from django.http import HttpResponse
from .models import Yangilik


def hello(request):
    yangiliklar = Yangilik.objects.all()
    context = {'yangiliklar': yangiliklar}
    return render(request, 'index.html', context=context)


# def uzbekistan(request):
#     return HttpResponse("O`zbekiston")
#
#
def jahon(request):
    return render(request, 'jahon.html')


#
#
# def iqtisodiyot(request):
#     return HttpResponse("Iqtisodiyot")
#
#
# def jamiyat(request):
#     return HttpResponse("Jamiyat")
#
#
def sport(request):
    return render(request, 'sport.html')
#
#
# def fantexnika(request):
#     return HttpResponse("Fan-texnika")
#
#
# def nuqtayinazar(request):
#     return HttpResponse("Nuqtiy nazar")
#
#
# def audio(request):
#     return HttpResponse("Audio")