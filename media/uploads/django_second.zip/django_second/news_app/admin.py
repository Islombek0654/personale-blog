from django.contrib import admin
from .models import Yangiliklar

admin.site.register(Yangiliklar)



