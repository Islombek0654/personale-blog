import sqlite3

class Database:
    def __init__(self):
        self.conn = sqlite3.connect('eco.db')
        self.cursor = self.conn.cursor()

    def create_tables(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS shikoyatlar
                            (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                            image TEXT,
                            latitude REAL NOT NULL,
                            longitude REAL NOT NULL)''')
        self.conn.commit()


    def create_tables(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS shikoyatlar1
                            (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                            image TEXT,
                            description TEXT,
                            latitude REAL NOT NULL,
                            longitude REAL NOT NULL)''')
        self.conn.commit()
    

    def shikoyat(self,image, latitude, longitude):
        self.cursor.execute("INSERT INTO shikoyatlar (image, latitude, longitude) VALUES (?, ?, ?)", (image, latitude, longitude))
        self.conn.commit()


    def shikoyat1(self,image, description, latitude, longitude):
        self.cursor.execute("INSERT INTO shikoyatlar1 (image, description, latitude, longitude) VALUES (?, ?, ?, ?)", (image, description, latitude, longitude))
        self.conn.commit()



    def get_shikoyatlar(self, image, latitude, longitude):
        self.cursor.execute("SELECT * FROM shikoyatlar WHERE id =?", (image, latitude, longitude))
        return self.cursor.fetchall()[0]


    def drop_table(self):
        self.cursor.execute('''Drop table shikoyatlar''')
        self.conn.commit()