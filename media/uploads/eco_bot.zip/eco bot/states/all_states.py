from aiogram.dispatcher.filters.state import StatesGroup, State


class eco_startstate(StatesGroup):
    media = State()
    location = State()
    phone = State()


class eco_startstate_two(StatesGroup):
    media = State()
    location = State()
    phone = State()



class eco_startstate_three(StatesGroup):
    media = State()
    location = State()
    phone = State()



class eco_startstate_four(StatesGroup):
    media = State()
    description = State()
    location = State()
    phone = State()



class eco_state_state(StatesGroup):
    id_card = State()
    nima = State()