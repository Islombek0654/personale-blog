from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


eco_start = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton('🌳 Noqinuniy daraxt kesish!'),
            KeyboardButton('🚮 Noqonunity axlat tashash!')
        ],
        [
            KeyboardButton('🏗️ Noqonuniy qurilish'),
            KeyboardButton('⭕ Boshqa ekologiyaga zararli narsa')
        ],
        [
            KeyboardButton('ℹ️ Biz haqimizda'),
            KeyboardButton('✍️ Fikr bildirish')
        ],
        [
            KeyboardButton("🤑Mukofotni olish!")
        ]
    ],resize_keyboard=True,
)


location = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton('📍 Lokatsiyani yuborish', request_location=True)
        ]
    ], resize_keyboard=True,
)




ball = ReplyKeyboardMarkup(
      keyboard=[
            [
                  KeyboardButton("Hammasi yoqdi ❣️")
            ],
            [
                  KeyboardButton("Yaxshi ⭐⭐⭐⭐")
            ],
            [
                  KeyboardButton("Yoqadi ⭐⭐⭐")
            ],
            [
                  KeyboardButton("Yomon ⭐⭐")
            ],
            [
                  KeyboardButton("Juda yomon 👎🏻")
            ],
            [
                  KeyboardButton("⬅️ Ortga3")
            ],
      ], resize_keyboard=True,
)