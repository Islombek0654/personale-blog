from aiogram import types
from loader import dp, db
from states.all_states import eco_startstate, eco_startstate_two, eco_startstate_three, eco_startstate_four, \
    eco_state_state
from keyboards.default.default_keyboards import location, eco_start, ball
from aiogram.dispatcher import FSMContext


@dp.message_handler(text='🌳 Noqinuniy daraxt kesish!', state=None)
async def daraxt(message: types.Message, state: FSMContext):
    await message.answer('Rasm yuboring!')
    await eco_startstate.media.set()


@dp.message_handler(content_types=types.ContentTypes.PHOTO, state=eco_startstate.media)
async def media(message: types.Message, state: FSMContext):
    image = message.photo[0].file_id
    await state.update_data(image=image)
    await message.answer('Manashu tugmaga bosing va usha joyni lokatsiyasini yuboring', reply_markup=location)
    await eco_startstate.location.set()


@dp.message_handler(content_types=types.ContentTypes.LOCATION, state=eco_startstate.location)
async def loc(message: types.Message, state: FSMContext):
    latitude = message.location.latitude
    longitude = message.location.longitude
    await state.update_data(latitude=latitude, longitude=longitude)
    data = await state.get_data()
    image = data['image']
    latitude = data['latitude']
    longitude = data['longitude']
    await message.answer("""
Bog`lanish uchun telefon raqam:
📱+998-90-929-12-90,
📱+998-33-342-12-90,
Murojatingiz uchun raxmat!
""", reply_markup=eco_start)
    db.shikoyat(image, latitude, longitude)
    await state.finish()


@dp.message_handler(text='🚮 Noqonunity axlat tashash!', state=None)
async def daraxt(message: types.Message, state: FSMContext):
    await message.answer('Rasm yuboring!')
    await eco_startstate_two.media.set()


@dp.message_handler(content_types=types.ContentTypes.PHOTO, state=eco_startstate_two.media)
async def media(message: types.Message, state: FSMContext):
    image = message.photo[0].file_id
    await state.update_data(image=image)
    await message.answer('Manashu tugmaga bosing va usha joyni lokatsiyasini yuboring', reply_markup=location)
    await eco_startstate_two.location.set()


@dp.message_handler(content_types=types.ContentTypes.LOCATION, state=eco_startstate_two.location)
async def loc(message: types.Message, state: FSMContext):
    latitude = message.location.latitude
    longitude = message.location.longitude
    await state.update_data(latitude=latitude, longitude=longitude)
    data = await state.get_data()
    image = data['image']
    latitude = data['latitude']
    longitude = data['longitude']
    await message.answer("""
Bog`lanish uchun telefon raqam:
📱+998-90-929-12-90,
📱+998-33-342-12-90,
Murojatingiz uchun raxmat!
""", reply_markup=eco_start)
    db.shikoyat(image, latitude, longitude)
    await state.finish()


@dp.message_handler(text='🏗️ Noqonuniy qurilish', state=None)
async def daraxt(message: types.Message, state: FSMContext):
    await message.answer('Rasm yuboring!')
    await eco_startstate_three.media.set()


@dp.message_handler(content_types=types.ContentTypes.PHOTO, state=eco_startstate_three.media)
async def media(message: types.Message, state: FSMContext):
    image = message.photo[0].file_id
    await state.update_data(image=image)
    await message.answer('Manashu tugmaga bosing va usha joyni lokatsiyasini yuboring', reply_markup=location)
    await eco_startstate_three.location.set()


@dp.message_handler(content_types=types.ContentTypes.LOCATION, state=eco_startstate_three.location)
async def loc(message: types.Message, state: FSMContext):
    latitude = message.location.latitude
    longitude = message.location.longitude
    await state.update_data(latitude=latitude, longitude=longitude)
    data = await state.get_data()
    image = data['image']
    latitude = data['latitude']
    longitude = data['longitude']
    await message.answer("""
Bog`lanish uchun telefon raqam:
📱+998-90-929-12-90,
📱+998-33-342-12-90,
Murojatingiz uchun raxmat!
""", reply_markup=eco_start)
    db.shikoyat(image, latitude, longitude)
    await state.finish()


@dp.message_handler(text='⭕ Boshqa ekologiyaga zararli narsa', state=None)
async def daraxt(message: types.Message, state: FSMContext):
    await message.answer('Rasm yuboring!')
    await eco_startstate_four.media.set()


@dp.message_handler(content_types=types.ContentTypes.PHOTO, state=eco_startstate_four.media)
async def media(message: types.Message, state: FSMContext):
    image = message.photo[0].file_id
    await state.update_data(image=image)
    await message.answer('Shikoyatingizni tavsifini kiriting')
    await eco_startstate_four.description.set()


@dp.message_handler(state=eco_startstate_four.description)
async def description(message: types.Message, state: FSMContext):
    description = message.text
    await state.update_data(description=description)
    await message.answer('Manashu tugmaga bosing va usha joyni lokatsiyasini yuboring', reply_markup=location)
    await eco_startstate_four.location.set()


@dp.message_handler(content_types=types.ContentTypes.LOCATION, state=eco_startstate_four.location)
async def loc(message: types.Message, state: FSMContext):
    latitude = message.location.latitude
    longitude = message.location.longitude
    await state.update_data(latitude=latitude, longitude=longitude)
    data = await state.get_data()
    image = data['image']
    description = data['description']
    latitude = data['latitude']
    longitude = data['longitude']
    await message.answer("""
Bog`lanish uchun telefon raqam:
📱+998-90-929-12-90,
📱+998-33-342-12-90,
Murojatingiz uchun raxmat!
""", reply_markup=eco_start)
    db.shikoyat1(image, description, latitude, longitude)
    await state.finish()


@dp.message_handler(text='ℹ️ Biz haqimizda')
async def haq(message: types.Message):
    await message.answer("""
Biz shunaqa kompaniyaki, xalqaro ekologiyasini toza tutishga yordam berasiz!
Agar siz ekologiyani buzayotganlarni kursangiz iltimos bizning saytimizga yokida botimizga murojaat qiling!
""")


@dp.message_handler(text='✍️ Fikr bildirish')
async def fikr(message: types.Message):
    await message.answer("""
✅ Street 77ni tanlaganingiz uchun rahmat.
Agar Siz bizning hizmatlarimiz sifatini yaxshilashga yordam bersangiz, bundan benihoya xursand bo'lamiz.
Buning uchun 5 ballik tizim asosida baholang
""", reply_markup=ball)


@dp.message_handler(text='Hammasi yoqdi ❣️')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=eco_start)


@dp.message_handler(text='Yaxshi ⭐⭐⭐⭐')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=eco_start)


@dp.message_handler(text='Yoqadi ⭐⭐⭐')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=eco_start)


@dp.message_handler(text='Yomon ⭐⭐')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=eco_start)


@dp.message_handler(text='Juda yomon 👎🏻')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=eco_start)


@dp.message_handler(text='🤑Mukofotni olish!')
async def pul(message: types.Message):
    await message.answer('Siz robot masmisiz, agar robot bo`lmasaiz kichkina harflar bilan "bot" deb yozin')
    await eco_state_state.id_card.set()


@dp.message_handler(text='bot', state=eco_state_state.id_card)
async def id_card(message: types.Message, state: FSMContext):
    await message.answer('Mukofotni olish uchun karta raqamingizni yuboting!')
    await eco_state_state.nima.set()


@dp.message_handler(state=eco_state_state.nima)
async def nima(message: types.Message, state: FSMContext):
    await message.answer('Karta raqamingizga pul tushdi!')
    await state.finish()
