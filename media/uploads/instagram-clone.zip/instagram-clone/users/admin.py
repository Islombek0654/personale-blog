from django.contrib import admin

from users.models import CustomUser, Messages


admin.site.register(Messages)
