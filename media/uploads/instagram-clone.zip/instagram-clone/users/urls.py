from django.urls import path
from .views import register, verify_email, main_page, login_view, register_view, logout_view, profile_view, \
    edit_profile_view

urlpatterns = [
    path("", main_page, name='home'),
    path('register/', register, name='register'),
    path('verify_email/', verify_email, name='verify_email'),
    path('login/', login_view, name='login'),
    path('sighnup/', register_view, name='sighnup'),
    path('logout/', logout_view, name='logout'),
    path('profile/', profile_view, name='profile'),
    path('edit/', edit_profile_view, name='edit'),
]
