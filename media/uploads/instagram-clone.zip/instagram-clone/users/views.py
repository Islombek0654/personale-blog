from django.conf import settings
from django.contrib.auth.forms import AuthenticationForm
from django.db import IntegrityError
from django.shortcuts import render, redirect
import random
import string
from django.core.mail import send_mail
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import login, logout
from .models import CustomUser, EmailVerification
from .forms import CustomUserCreationForm, Sighn_up_Form, Edit_form
from posts.models import Post


def main_page(request):
    posts = Post.objects.all()
    return render(request, 'base.html', {'posts': posts})


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False  # User is initially inactive until verified
            user.set_password(form.cleaned_data['password1'])  # Parolni hash qilish
            user.save()

            # Tasdiqlash kodi yaratish
            confirmation_code = random.randint(100000, 999999)
            request.session['confirmation_code'] = confirmation_code
            request.session['user_id'] = user.id

            # Tasdiqlash kodini email orqali yuborish
            send_mail(
                'Tasdiqlash kodingiz',
                f'Tasdiqlash kodi: {confirmation_code}',
                settings.DEFAULT_FROM_EMAIL,
                [user.email],
                fail_silently=False,
            )
            return redirect('verify_email')  # Tasdiqlash sahifasiga o'tish
    else:
        form = CustomUserCreationForm()

    return render(request, 'register.html', {'form': form})


def verify_email(request):
    if request.method == 'POST':
        input_code = request.POST.get('confirmation_code')
        user_id = request.session.get('user_id')
        confirmation_code = request.session.get('confirmation_code')

        if str(input_code) == str(confirmation_code):
            user = CustomUser.objects.get(id=user_id)
            user.is_active = True  # Activate user after verification
            user.is_verified = True
            user.save()
            login(request, user)
            return redirect('home')  # Asosiy sahifaga o'tish
        else:
            return render(request, 'verify_email.html', {'error': 'Tasdiqlash kodi noto‘g‘ri'})

    return render(request, 'verify_email.html')


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})


def register_view(request):
    if request.method == 'POST':
        form = Sighn_up_Form(request.POST, request.FILES)
        if form.is_valid():
            username = form.cleaned_data['username']
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            email = form.cleaned_data['email']
            phone_number = form.cleaned_data['phone_number']
            avatar = form.cleaned_data['avatar']
            password = form.cleaned_data['password1']

            user = CustomUser.objects.create_user(
                username=username,
                first_name=first_name,
                last_name=last_name,
                email=email,
                phone_number=phone_number,
                avatar=avatar,
                password=password
            )
            user.set_password(password)
            user.save()

            return redirect('home')
    else:
        form = Sighn_up_Form()
    return render(request, 'signup.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('home')


def profile_view(request):
    data = CustomUser.objects.get(id=request.user.id)
    posts = Post.objects.all()
    context = {
        'data': data,
        'posts': posts
    }
    return render(request, 'profile.html', context)


def edit_profile_view(request):
    if request.method == 'POST':
        form = Edit_form(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = Edit_form(instance=request.user)
    return render(request, 'edit_profile.html', {'form': form})
