from django.shortcuts import render, redirect
from .models import Post, Commentary

def add_comment(request, post_id):
    post = Post.objects.get(pk=post_id)
    if request.method == 'POST':
        comment = request.POST['comment']
        Commentary.objects.create(user=request.user, post=post, content=comment)
        return redirect('add_comment', post_id=post_id)
    else:
        comments = Commentary.objects.all().filter(post=post)
        return render(request, 'add_comment.html', {'post': post, 'comments': comments})