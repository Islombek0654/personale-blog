from django.forms import ModelForm
from .models import Commentary


class Sighn_up_Form(ModelForm):
    class Meta:
        model = Commentary
        fields = ('content', 'post', 'created_at', 'user')

