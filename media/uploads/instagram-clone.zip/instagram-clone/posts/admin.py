from django.contrib import admin

from posts.models import Post, Commentary

admin.site.register(Post)
admin.site.register(Commentary)