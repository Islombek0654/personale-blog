from django.urls import path
from .views import add_comment

urlpatterns = [
    path('<int:post_id>/comments/', add_comment, name='add_comment'),
]
    