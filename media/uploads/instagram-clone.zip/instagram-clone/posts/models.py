from django.db import models
from users.models import CustomUser


class Post(models.Model):
    image = models.ImageField(upload_to='image/')
    video = models.FileField(blank=True, null=True)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='posts')


class Commentary(models.Model):
    content = models.TextField()
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='commentaries')
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='comments')


class PostLike(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='post_likes')
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='postss')
    created_at = models.DateTimeField(auto_now_add=True)



class CommentLike(models.Model):
    comment = models.ForeignKey(Commentary, on_delete=models.CASCADE, related_name='like_comment')
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='liked_comment')
    created_at = models.DateTimeField(auto_now_add=True)