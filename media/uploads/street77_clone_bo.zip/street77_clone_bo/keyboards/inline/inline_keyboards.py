from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from loader import db


async def get_categories_btn():
    categories = db.get_categories()

    categories_btn = InlineKeyboardMarkup(row_width=2)

    btns = []
    for category in categories:
        btns.append(InlineKeyboardButton(category[1], callback_data=f'category_{category[0]}'))

    categories_btn.add(*btns)
    return categories_btn


async def get_products_btn(category_id):
    products = db.get_products(category_id)

    products_btn = InlineKeyboardMarkup(row_width=2)

    btns = []
    for product in products:
        btns.append(InlineKeyboardButton(product[1], callback_data=f'product_{product[0]}'))

    products_btn.add(*btns)
    return products_btn




beruniy = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton("💰Savat(0 so`m)", callback_data='INbasket')
        ],
        [
            InlineKeyboardButton("🔥🐔 Акция курочка", callback_data="INaksiyach"),
            InlineKeyboardButton("🎉AKSIYA", callback_data="INaksiyajust")
        ],
        [
            InlineKeyboardButton("🍔BURGERS", callback_data="INburger"),
            InlineKeyboardButton("🐔Qanotchalar", callback_data="INqanotcha")
        ],
        [
            InlineKeyboardButton("🍕Pizza", callback_data="INpizza"),
            InlineKeyboardButton("🌯Rollar", callback_data="vrolls")
        ],
        [
            InlineKeyboardButton("🍟Snacks", callback_data="INsnack"),
            InlineKeyboardButton("🌭Hot-Dog", callback_data="INhotdog")
        ],
        [
            InlineKeyboardButton("🥗Salatlar", callback_data="INsalad"),
            InlineKeyboardButton("🍭Bolalar uchun", callback_data="INloll")
        ],
        [
            InlineKeyboardButton("🥤Sovuq ichimliklar", callback_data="INwater"),
            InlineKeyboardButton("🥫Souslar", callback_data="INsous")
        ],
        [
            InlineKeyboardButton("🍹Kokteylar", callback_data="INkokteyl"),
        ],
    ], row_width=2,
)



in_ber = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton("💰Savat(0 so`m)", callback_data='INbasket')
        ],
        [
            InlineKeyboardButton("Острые.", callback_data='spicy'),
            InlineKeyboardButton("Не острые.", callback_data='notspicy')
        ],
        [
            InlineKeyboardButton("⬅️ Ortga", callback_data='back')
        ],
    ],
)