from loader import dp, db
from aiogram import types
from keyboards.default.default_keyboards import menu_to_user, menu_deliever, main_menu, menu_foot, ball
from keyboards.inline.inline_keyboards import beruniy, in_ber
from states.all_states import YetkazishState, Beruniy
from aiogram.dispatcher import FSMContext
from keyboards.inline.inline_keyboards import get_categories_btn, get_products_btn

@dp.message_handler(text="🍽 Menyu")
async def menu_handler(message: types.Message):
    await message.answer("birini tanglang", reply_markup=menu_to_user)

@dp.message_handler(text="🚙 Yetkazib berish")
async def get_order(message: types.Message):
    await message.answer("Lakatsiyani yuboring")
    await YetkazishState.lokatsiya.set()

@dp.message_handler(content_types=["location"], state=YetkazishState.lokatsiya)
async def set_location(message: types.Message, state: FSMContext):
    location = message.location
    latitude = location.latitude
    longitude = location.longitude
    await state.update_data(latitude=latitude, longitude=longitude)
    await message.answer("Kategoriyani tanlang", reply_markup= await get_categories_btn())
    await YetkazishState.category.set()

@dp.callback_query_handler(lambda c: c.data.startswith("category_"), state=YetkazishState.category)
async def get_products_handler(call: types.CallbackQuery, state: FSMContext):
    category_id = call.data.split("_")[1]
    print(category_id)
    await call.message.answer("Productlardan birini tanlang", reply_markup=await get_products_btn(category_id))
    await YetkazishState.product.set()


@dp.callback_query_handler(lambda c: c.data.startswith("product_"), state=YetkazishState.product)
async def get_products_handler(call: types.CallbackQuery, state: FSMContext):
    product_id = int(call.data.split('_')[1])
    product = db.get_product(product_id)
    print(product)
    image = product[4]
    caption = f'{product[3]}\n{product[2]}'
    await call.message.answer_photo(photo=image, caption=caption)
    await state.finish()
    

@dp.message_handler(text='⬅️ Ortga')
async def back_one(message: types.Message):
    await message.answer("Bosh menyu", reply_markup=main_menu)
    

@dp.message_handler(text='🗺 Mening manzillarim')
async def map(message: types.Message):
    await message.answer("Manzilni tanlang yoki kiriting: ")


@dp.message_handler(text='⬅️ Ortga1')
async def back2(message: types.Message):
    await message.answer("Buyurtmani o'zingiz olib keting yoki yetkazib berishni tanlang", reply_markup=menu_to_user)


@dp.message_handler(text='🏃 Olib ketish')
async def foot(message: types.Message):
    await message.answer("""
Qayerdasiz 👀?
Agar lokatsiyangizni📍 yuborsangiz, sizga eng yaqin filialni aniqlaymiz
""",reply_markup=menu_foot)
    

@dp.message_handler(text='⬅️ Ortga2')
async def back2(message: types.Message):
    await message.answer("Buyurtmani o'zingiz olib keting yoki yetkazib berishni tanlang", reply_markup=menu_to_user)



@dp.message_handler(text='Wok & STREET77 Беруни')
async def beruniy(message: types.Message):
    await message.answer("Tanlangan filial: Wok & STREET77 Беруни")
    await Beruniy.olish.set()



@dp.callback_query_handler(lambda c: c.data.startswith('category_'), state=Beruniy.olish)
async def cat(call: types.CallbackQuery):
    await call.message.answer("""
Tanlangan filial: Wok & STREET77 Беруни
Nimadan boshlaymiz?
""", reply_markup=await get_categories_btn())


@dp.message_handler(text='📖 Buyurtmalar tarixi')
async def history(message:types.Message):
    await message.answer("Buyurtmalar tarixi yo'q, uni to'ldirishingiz kerak 😊")



@dp.message_handler(text='✍️ Fikr bildirish')
async def fikr(message:types.Message):
    await message.answer("""
✅ Street 77ni tanlaganingiz uchun rahmat.
Agar Siz bizning hizmatlarimiz sifatini yaxshilashga yordam bersangiz, bundan benihoya xursand bo'lamiz.
Buning uchun 5 ballik tizim asosida baholang
""", reply_markup=ball)



@dp.message_handler(text='Hammasi yoqdi ❣️')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=ball)



@dp.message_handler(text='Yaxshi ⭐⭐⭐⭐')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=ball)



@dp.message_handler(text='Yoqadi ⭐⭐⭐')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=ball)



@dp.message_handler(text='Yomon ⭐⭐')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=ball)



@dp.message_handler(text='Juda yomon 👎🏻')
async def fikrh(message: types.Message):
    await message.answer('Fikringiz uchun raxmat', reply_markup=ball)



@dp.message_handler(text='⬅️ Ortga3')
async def back3(message: types.Message):
    await message.answer("Bosh menyu", reply_markup=main_menu)




@dp.message_handler(text='☎️ Biz bilan aloqa')
async def phone(message: types.Message):
    await message.answer("""
Agar sizda Savollar/Shikoyatlar/Takliflar bo'lsa bizga yozishingiz mumkin: @Street77tech_bot

☎️ Telefon raqam: 71-200-73-73 / 71 200-86-86
""", reply_markup=main_menu)