from django.contrib.auth.models import AbstractUser
from django.db import models


class CustomUser(AbstractUser):
    username = models.CharField(max_length=150, unique=True, default='default_username')
    phone_number = models.IntegerField(null=True, blank=True)
    bio = models.TextField(null=True, blank=True)
    subscribes = models.TextField(null=True, blank=True)
    profile_avatar = models.ImageField(upload_to='media/', default='images/avatar.jpg')
    follower = models.ManyToManyField('self', symmetrical=False, related_name='following', blank=True)

    def __str__(self):
        return self.username


class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Channel(models.Model):
    channel_owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name="channel_user")
    channel_name = models.CharField(max_length=250)
    channel_bio = models.TextField(null=True, blank=True)
    channel_subscribers = models.TextField(null=True, blank=True)
    channel_avatar = models.ImageField(upload_to='channel_avatars/', null=True, default='channel_owner.profile_avatar')
    category_channel = models.ForeignKey(Category, on_delete=models.CASCADE)

    def __str__(self):
        return self.channel_name


class Video(models.Model):
    video_owner = models.ForeignKey(Channel, on_delete=models.CASCADE, related_name='video_user')
    video_text = models.TextField(blank=True)
    video = models.FileField(null=True, blank=True)
    video_image = models.ImageField(upload_to='video_images/', null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True, null=True)


class Commentary(models.Model):
    content = models.TextField()
    video = models.ForeignKey(Video, on_delete=models.CASCADE, related_name='commentaries')
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='comments')


class Like(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)
    blog = models.ForeignKey(Video, on_delete=models.CASCADE)
