from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, Http404
from django.shortcuts import render, redirect, get_object_or_404
from .models import CustomUser, Channel, Video, Commentary, Like
from .forms import LoginForm, RegisterUserForm


def home_page(request):
    user = CustomUser.objects.all()
    video = Video.objects.all()

    context = {
        'photo_video': video,
        'user': user
    }

    return render(request, 'index.html', context)


def register(request):
    if request.method == "POST":
        form = RegisterUserForm(request.POST)
        print(form)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = RegisterUserForm()

    context = {
        "form": form
    }
    return render(request, 'all_register.html', context)


def log_in(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(username=form.cleaned_data['username'], password=form.cleaned_data['password'])
            if user:
                login(request, user)
                return redirect('/home/')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})


@login_required(login_url='/login')
def log_out(request):
    logout(request)
    return redirect('/login')


def inner_video(request, video_id):
    video = Video.objects.get(id=video_id)
    author = video.video_owner
    context = {
        'videos': video,
        'author': author
    }

    return render(request, 'inner.html', context)


def add_comment(request, post_id):
    post = Video.objects.get(id=post_id)
    if request.method == 'POST':
        comment = request.POST.get('comment', '')
        Commentary.objects.create(user=request.user, video=post, content=comment)
        # Возврат на предыдущую страницу
        referer = request.META.get('HTTP_REFERER')
        return redirect(referer if referer else 'default-url')  # В случае, если HTTP_REFERER отсутствует
    else:
        comments = Commentary.objects.filter(video=post)
        return render(request, 'comment.html', {'post': post, 'comments': comments})


def follow(request, user_id):
    # Получаем текущего пользователя и целевого пользователя (к которому подписываемся)
    url = request.META.get("HTTP_REFERER")  # Возвращаемся на страницу, с которой был запрос
    if request.user.id != user_id:  # Убедитесь, что пользователь не подписывается на самого себя
        author = get_object_or_404(CustomUser, id=user_id)
        # Проверяем, подписан ли пользователь
        if request.user not in author.follower.all():
            author.follower.add(request.user)  # Добавляем подписку
        else:
            author.follower.remove(request.user)  # Убираем подписку
    return redirect(url)


def like_dislike(request, blog_id):
    if Like.objects.filter(user=request.user.profile, blog__id=blog_id).exists():
        Like.objects.filter(user=request.user.profile, blog__id=blog_id).delete()
        return JsonResponse({"created": False})
    else:
        blog = Video.objects.get(id=blog_id)
        Like.objects.create(user=request.user.profile, blog=blog)
        return JsonResponse({"created": True})
