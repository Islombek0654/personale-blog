from django.apps import AppConfig


class MainYoutubeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'main_youtube'
