from django.urls import path
from .views import home_page, register, log_in, log_out, inner_video, add_comment, like_dislike, follow

urlpatterns = [
    path('home/', home_page, name="home"),
    path('signup/', register, name="register"),
    path('login/', log_in, name="login"),
    path('logout/', log_out, name="logout"),
    path('inner_video/<int:video_id>/', inner_video, name='inner'),
    path('comment/<int:post_id>', add_comment, name="comment"),
    path('like/', like_dislike, name="like"),
    path('follow/<int:user_id>/', follow, name="follow")
]
