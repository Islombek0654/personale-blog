from django.contrib import admin
from .models import Channel, CustomUser, Video, Category, Commentary

admin.site.register(Channel)
admin.site.register(CustomUser)
admin.site.register(Video)
admin.site.register(Category)
admin.site.register(Commentary)

